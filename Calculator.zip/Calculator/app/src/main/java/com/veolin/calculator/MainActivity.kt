package com.veolin.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val edtInput: EditText = findViewById<EditText>(R.id.edtInput)
        val edtInput2 = findViewById<EditText>(R.id.edtInput2)
        val edtMainAnswer = findViewById<TextView>(R.id.edtMainAnswer)


        val btnSub = findViewById<Button>(R.id.btnSub)
        btnSub.setOnClickListener {
            val Num1: Int = edtInput.text.toString().toInt()
            val Num2: Int = edtInput2.text.toString().toInt()
            val SubAns = Num1 - Num2
            edtMainAnswer.text = String.format("$Num1" + "-" + "$Num2" + "=" + "$SubAns")
        }
        val btnAdd = findViewById<Button>(R.id.btnAdd)
        btnAdd.setOnClickListener {
            val Num3: Int = edtInput.text.toString().toInt()
            val Num4: Int = edtInput2.text.toString().toInt()
            val AddAns = Num3 + Num4
            edtMainAnswer.text = String.format("$Num3" + "+" + "$Num4" + "=" + "$AddAns")
        }

            val btnDiv = findViewById<Button>(R.id.btnDiv)
            btnDiv.setOnClickListener {
                val Num5: Int = edtInput.text.toString().toInt()
                val Num6: Int = edtInput2.text.toString().toInt()
                if (Num6 === 0) {
                    edtMainAnswer.text = String.format("$Num5"+"cannot be divided by"+"$Num6")
                } else {
                val DivAns = Num5 / Num6
                edtMainAnswer.text = String.format("$Num5" + "÷" + "$Num6" + "=" + "$DivAns")
                    }

            }
            val btnMulti = findViewById<Button>(R.id.btnMulti)
            btnMulti.setOnClickListener {
                val Num7: Int = edtInput.text.toString().toInt()
                val Num8: Int = edtInput2.text.toString().toInt()
                val MultiAns = Num7 * Num8
                edtMainAnswer.text = String.format("$Num7" + "×" + "$Num8" + "=" + "$MultiAns")
            }
            val btnPower = findViewById<Button>(R.id.btnPower)
            btnPower.setOnClickListener {
                val Num11 = edtInput.text.toString().toInt()
                val Num12 = edtInput2.text.toString().toInt()
                val PowerAns = Math.pow(Num11.toDouble(), Num12.toDouble())
                edtMainAnswer.text = String.format("$Num11" + "^" + "$Num12" + "=" + "$PowerAns")
            }


             val btnSquare = findViewById<Button>(R.id.btnSquare)
             btnSquare.setOnClickListener {
                 val Num9: Int = edtInput.text.toString().toInt()
                 if (Num9 >= 0) {
                     val SquareAns = Math.sqrt(Num9.toDouble())
                     edtMainAnswer.text = String.format("sqrt(" + "$Num9" + ")" + "$SquareAns")
                 } else {
                     val SquareAns = Math.sqrt(Num9.toDouble())
                     edtMainAnswer.text = String.format("sqrt(" + "$Num9" + ")" + "$SquareAns"+"i")
                 }

             }

    }

}








